
import './App.css';
import { useState } from 'react';
import { Button, Modal } from 'react-bootstrap';
import React, { Component } from "react";
import {Route, BrowserRouter as Router, Switch,Link} from 'react-router-dom';
import Home from "./pages/home";
import ProductList from "./pages/product-list";
import ProductDetails from "./pages/product-details";
import VendorDetails from "./pages/vendor"

function App() {
  const [show, setShow] = useState(false);
  
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleSubmit = () => {
    console.log('you have submitted the form');
  }

  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex);
  };

  return (
    <div className="App">
      <nav className="navbar navbar-expand-sm navbar-dark navbar-custom">
      <a className="navbar-brand" href="#">
        <img className="main-logo" src="./logo-1.svg"/>
      </a>
  <ul className="navbar-nav ml-auto">
    <li className="nav-item">
      <Button className="mr-2" variant="secondary">
      Cart
        </Button>
    </li>
    <li className="nav-item">
      <Button className="mr-2" variant="secondary">
      Wallet
        </Button>
    </li>
    <li className="nav-item">
      <Button className="mr-2" variant="secondary" onClick={handleShow}>
          Sign up
        </Button>
    </li>
    <li className="nav-item">
      <Button variant="secondary" onClick={handleShow}>
          Login
        </Button>
    </li>
  </ul>
</nav>
  <nav className="navbar navbar-default">
    <div className="container-fluid secondary-menu">
      <a href="#/home">Home</a>
      <a href="#">Grocery</a>
      <a href="#">Home Care</a>
      <a href="#">Kitchen ware</a>
      <a href="#">Daily essentials</a>
    <a className="ml-auto app-store" href="#">Download the app
    <img className="download-app ml-2" src="./ios-icon.png" />
    <img className="download-app ml-2" src="./android-icon.jpeg"/>
    </a>
    </div>
  </nav>
  <Router>
    <Switch>
        <Route path="/" exact component={Home}/>
        <Route path="/product-list" component={ProductList}/>
        <Route path="/product-details" component={ProductDetails}/>
        <Route path="/vendor-details" component={VendorDetails}/>
        <Route path="*" exact component={Home}/>
      </Switch>
  </Router>
    <footer className="footer">
      <div className="row">
      <div className="col-3">
        <p>Know about us</p>
        <a>About Us</a>
        <a>Careers</a>
        <a>Blogs</a>
        </div>
        <div className="col-3">
        <p>Get in touch</p>
        <a>facebook</a>
        <a>instagram</a>
        <a>twitter</a>
        <a>linkedin</a>
        </div>
        <div className="col-3">
        <p>Enroll yourself</p>
        <a>Become our partner</a>
        <a>Become an affliate</a>
        <a>Advertise your brand</a>
        </div>
        <div className="col-3">
        <p>Contact US</p>
        <p className="footer-address">
          bangalore-560001
        </p>
        <a>Helpline number: 1234567890</a>
        <a>Email: customercare@tortecy.com</a>
        </div>
      </div>
      <hr />
      <p className="text-center">Designed & Developed by PartNets</p>
    </footer>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Sign Up</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form onSubmit={handleSubmit}>
          <label>First Name</label>
          <input className="form-control mb-3"
            type="text"
          />
          <label>Last Name</label>
          <input className="form-control mb-3"
            type="text"
          />
          <label>Email</label>
          <input className="form-control mb-3"
            type="email"
          />
          <label>Password</label>
          <input className="form-control mb-3"
            type="password"
          />
          <label>Confirm Password</label>
          <input className="form-control mb-4"
            type="password"
          />
          <div className="text-center mt-2">
          <Button variant="secondary" type="submit">
            Submit
          </Button>
          </div>
        </form>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default App;
