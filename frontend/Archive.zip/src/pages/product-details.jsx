
import React from 'react';

export default function ProductDetails(){
    return (
        <div className="container-fluid p-5">
        <div className="row">
            <div className="col-6 col-md-4">
            <img src="./onion.jpg" className="mb-4"/>
                        <button className="primary mr-2">Add to Cart</button>
                        <button className="secondary">Buy Now</button>
            </div>
            <div className="col-6 col-md-8 text-left">
                <p className="prodDesc">Fresh Onion - Antibiotic Residue-Free, Growth Hormone-Free, 1 kg</p>
                <p className="price">Price: Rs 49</p>
            </div>
        </div>
        <hr />
        <div className="row mt-4">
            <h2>Reviews</h2>

        </div>
        </div>
    );
}