import React from 'react';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import {Link} from 'react-router-dom';

export default function Home(){
    const responsive = {
        superLargeDesktop: {
          breakpoint: { max: 4000, min: 3000 },
          items: 5
        },
        desktop: {
          breakpoint: { max: 3000, min: 1024 },
          items: 4
        },
        tablet: {
          breakpoint: { max: 1024, min: 464 },
          items: 2
        },
        mobile: {
          breakpoint: { max: 464, min: 0 },
          items: 1
        }
      };

    return (
        <div>
                  <img className="banner-image" src="./banner-image.jpg" />

<h2>Categories</h2>
<Carousel responsive={responsive}>
<div className="category-item">
  <Link to={"/product-list"}>
    <img src="./onion.jpg"/>
    <p>Groceries</p>
  </Link>
</div>
<div className="category-item">
<Link to={"/product-list"}>
  <img src="./tomato_small.png"/>
  <p>Home Care</p>
  </Link>
</div>
<div className="category-item">
<Link to={"/product-list"}>
  <img src="./cauliflower.png"/>
  <p>Kitchen ware</p>
  </Link>
</div>
<div className="category-item">
<Link to={"/product-list"}>
  <img src="./pepper.jpg"/>  
  <p>Daily essentials</p>
  </Link>
</div>
<div className="category-item">
<Link to={"/product-list"}>
  <img src="./onion.jpg"/>
  <p>Groceries</p>
  </Link>
</div>
<div className="category-item">
<Link to={"/product-list"}>
  <img src="./tomato_small.png"/>
  <p>Home Care</p>
  </Link>
</div>
<div className="category-item">
<Link to={"/product-list"}>
  <img src="./cauliflower.png"/>
  <p>Kitchen ware</p>
  </Link>
</div>
<div className="category-item">
<Link to={"/product-list"}>
  <img src="./pepper.jpg"/>  
  <p>Daily essentials</p>
  </Link>
</div>
</Carousel>
        </div>
    );
}