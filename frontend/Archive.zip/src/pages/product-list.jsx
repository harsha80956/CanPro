
import React, {Component} from 'react';
import {Link} from 'react-router-dom';

class ProductList extends Component{
    constructor(){
        super();
    }
    state = {
        count: 0,
        items: [
            {
                id:"1",
                img: "./onion.jpg",
                desc: "Onion",
                discountPrice: "60",
                actualPrice:"50"
            },
            {
                id:"2",
                img: "./tomato_small.png",
                desc: "Home Care",
                discountPrice: "60",
                actualPrice:"50"
            },
            {
                id:"3",
                img: "./cauliflower.png",
                desc: "Kitchen ware",
                discountPrice: "60",
                actualPrice:"50"
            },
            {
                id:"1",
                img: "./pepper.jpg",
                desc: "Daily essentials",
                discountPrice: "60",
                actualPrice:"50"
            }
        ]
    }
    render(){
        return(
        <div className="container-fluid">
            <div className="row">
            <div className="col-12 col-md-3">
                <h3>Filter By</h3>
                <p className="filterLabel"></p>
            </div>
            <div className="col-12 col-md-9">
                <div className="category-item">
                <Link to={"/product-details"}>
                    <span className="foodCategory"></span>
                    <img src="./onion.jpg"/>
                    <p>Onion</p>
                    <p className="price"><span className="discount">₹60</span> <b>₹ 50</b></p>
                </Link>
                <button className="primary">Add to Cart</button>
            </div>
                <div className="category-item">
                <Link to={"/product-details"}>
                <span className="foodCategory"></span>
                <img src="./tomato_small.png"/>
                <p>Home Care</p>
                <p className="price"><span className="discount">₹60</span> <b>₹ 50</b></p>
                </Link>
                <button className="primary">Add to Cart</button>
                </div>
                <div className="category-item">
                <Link to={"/product-details"}>
                <span className="foodCategory"></span>
                <img src="./cauliflower.png"/>
                <p>Kitchen ware</p>
                <p className="price"><span className="discount">₹60</span> <b>₹ 50</b></p>
                </Link>
                <button className="primary">Add to Cart</button>
                </div>
                <div className="category-item">
                    <Link to={"/product-details"}>
                    <span className="foodCategory"></span>
                    <img src="./pepper.jpg"/>  
                    <p>Daily essentials</p>
                    <p className="price"><span className="discount">₹60</span> <b>₹ 50</b></p>
                    </Link>
                    <button className="primary">Add to Cart</button>
                </div>
            </div>
            </div>
        </div>
        );
    }
}
export default ProductList;